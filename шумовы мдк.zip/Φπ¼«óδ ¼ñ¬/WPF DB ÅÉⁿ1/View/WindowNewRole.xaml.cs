﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WPF_DB_ПР_1.Model;
using WPF_DB_ПР_1.ViewModel;

namespace WPF_DB_ПР_1.View
{
    /// <summary>
    /// Логика взаимодействия для WindowNewRole.xaml
    /// </summary>
    public partial class WindowNewRole : Window
    {
        public WindowNewRole()
        {
            InitializeComponent();
        }

        private void BtSave_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(TbRole.Text))
            {
                MessageBox.Show("Введите название должности", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            DialogResult = true;

            if (this.DataContext is Role role)
            {
                role.NameRole = TbRole.Text; 
            }
        }

        private void OpenEditWindow()
        {
            WindowNewRole vnRole = new WindowNewRole();
            {
                Title = "Редактирование должности";
                Owner = this;
            }
            vnRole.ShowDialog();
        }
    }
}
