﻿using WpfApplDemo2018.Helper;
using System.Collections.Generic;
using System;
using System.Collections.ObjectModel;
using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Windows;
using WPF_DB_ПР_1.Helper;
using WPF_DB_ПР_1.Model;
using WPF_DB_ПР_1.ViewModel;
using WPF_DB_ПР_1;
using WPF_DB_ПР_1.View;
namespace WpfApplDemo2018.View
{
    /// <summary> 
    /// Логика взаимодействия для WindowEmployee.xaml 
    /// </summary> 
    public partial class WindowEmployee : Window
    {
        private PersonViewModel vmPerson;
        public RoleViewModel vmRole;
        public ObservableCollection<PersonDPO> personsDPO;
        public List<Role> roles;

        public WindowEmployee()
        {
            InitializeComponent();

            vmPerson = new PersonViewModel();
            vmRole = new RoleViewModel();

            roles = new List<Role>(vmRole.ListRole); // Загружаем все роли

            personsDPO = new ObservableCollection<PersonDPO>(); // Основная коллекция для отображения

            // Заполняем personsDPO данными
            foreach (var p in vmPerson.ListPerson)
            {
                Role rol = roles.FirstOrDefault(r => r.Id == p.RoleId);
                personsDPO.Add(new PersonDPO
                {
                    Id = p.Id,
                    NameRole = rol.NameRole,
                    FirstName = p.FirstName,
                    LastName = p.LastName,
                    Birthday = p.Birthday,
                });
            }

            lvEmployee.ItemsSource = personsDPO; // Привязываем коллекцию к ListView
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            WindowNewEmployee wnEmployee = new WindowNewEmployee
            {
                Title = "Новый сотрудник",
                Owner = this
            };

            int maxIdPerson = vmPerson.MaxId() + 1;
            PersonDPO per = new PersonDPO
            {
                Id = maxIdPerson, 
                Birthday = DateTime.Now
            };

            wnEmployee.DataContext = per;
            wnEmployee.CbRole.ItemsSource = roles;
            wnEmployee.CbRole.DisplayMemberPath = "NameRole";
            wnEmployee.CbRole.SelectedValuePath = "Id";

            if (wnEmployee.ShowDialog() == true)
            {
                Role selectedRole = (Role)wnEmployee.CbRole.SelectedItem;

                if (selectedRole == null)
                {
                    MessageBox.Show("Роль не выбрана!");
                    return;
                }
                per.NameRole = selectedRole.NameRole;
                personsDPO.Add(per);
                Person newPerson = new Person
                {
                    Id = per.Id, 
                    RoleId = selectedRole.Id,
                    FirstName = per.FirstName,
                    LastName = per.LastName,
                    Birthday = per.Birthday
                };
                vmPerson.ListPerson.Add(newPerson);
            }
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            //WindowsNewEmployee wnEmployee = new WindowsNewEmployee
            //{
            //    Title = "Редактирование данных",
            //    Owner = this
            //};

            //PersonDpo perDPO = (PersonDpo)lvEmployee.SelectedValue;
            //if (perDPO != null)
            //{
            //    PersonDpo tempPerDPO = perDPO.ShallowCopy();
            //    wnEmployee.DataContext = tempPerDPO;
            //    wnEmployee.CbRole.ItemsSource = roles;
            //    wnEmployee.CbRole.Text = tempPerDPO.Role;

            //    if (wnEmployee.ShowDialog() == true)
            //    {
            //        Role r = (Role)wnEmployee.CbRole.SelectedValue;
            //        perDPO.Role = r.NameRole;
            //        perDPO.FirstName = tempPerDPO.FirstName;
            //        perDPO.LastName = tempPerDPO.LastName;
            //        perDPO.Birthday = tempPerDPO.Birthday;
            //        lvEmployee.ItemsSource = null;
            //        lvEmployee.ItemsSource = personsDPO;

            //        FindPerson finder = new FindPerson(perDPO.Id);
            //        Person p = vmPerson.ListPerson.FirstOrDefault(person => finder.PersonPredicate(person));

            //        p = p.CopyFromPersonDPO(perDPO);
            //    }
            //}
            //else
            //{
            //    MessageBox.Show("Необходимо выбрать сотрудника для редактирования", "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
            //}
        } 

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            PersonDPO person = (PersonDPO)lvEmployee.SelectedItem;
            if (person != null)
            {
                MessageBoxResult result = MessageBox.Show("Удалить данные по сотруднику: \n" + person.LastName +" "+person.FirstName, 
            
                 "Предупреждение", MessageBoxButton.OKCancel, MessageBoxImage.Warning);
                if (result == MessageBoxResult.OK)
                {
                    // удаление данных в списке отображения данных 
                    personsDPO.Remove(person);
                    // удаление данных в списке классов ListPerson<Person> 
                    Person per = new Person();
                    per = per.CopyFromPersonDPO(person);
                    vmPerson.ListPerson.Remove(per);
                }
            }
            else
            {
                MessageBox.Show("Необходимо выбрать данные по сотруднику для удаления", 
            
                 "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

    }
}