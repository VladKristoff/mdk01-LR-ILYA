﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace WPF_DB_ПР_1.Helper
{
    public class PersonDPO
    {
        public int Id { get; set; }

        private string _roleName;
        public string NameRole
        {
            get { return _roleName; }
            set
            {
                _roleName = value;
            }
        }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime Birthday { get; set; }

        public PersonDPO() { }
        public PersonDPO(int id, string role, string firstName, string lastName, DateTime birthday)

        {
            this.Id = id;
            this.NameRole = role;
            this.FirstName = firstName;
            this.LastName = lastName;
            this.Birthday = birthday;
        }

        public PersonDPO ShallowCopy()
        {
            return (PersonDPO)this.MemberwiseClone();
        }
    }
}
