﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPF_DB_ПР_1.Helper
{
    internal class FindPerson
    {
        public int Id;

        public FindPerson(int id)
        {
            this.Id = id;
        }

        public bool PersonPredicate(PersonDPO person)
        {
            return person.Id == Id;
        }
        
    }
}
