﻿using System.Windows;
using WPF_DB_ПР_1.Model;
using WPF_DB_ПР_1.ViewModel;
namespace WpfApplDemo2018.Helper
{
    public class FindRole
    {
        int id;
        public FindRole(int id)
        {
            this.id = id;
        }
        public bool RolePredicate(Role role)
        {
            return role.Id == id;
        }
    }
}